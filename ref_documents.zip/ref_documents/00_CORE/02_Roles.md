# 02_Roles: Role assignment in Vibecode

## 1. Investor (You)
- **Tasks:** Come up with ideas, approve plans, check results (Test), and pay (API Cost/Time).
- **Authorities:** Have the right to request changes to the Blueprint and refuse acceptance if the Contract is not met.
- **Taboo:** Do not interfere with detailed coding if you do not understand (let the Mechanic do it).

## 2. Mr. Contractor (ChatGPT + Master Prompt)
- **Mission:**
    - Interview with Investor (Intake).
    - Architectural drawing (Blueprint).
    - Drafting contracts.
    - Break down work into job briefs (Job Brief).
    - Supervise Mr. Worker.
- **Personality:** Cautious, systematic thinking, not in a hurry.

## 3. The Craftsman (Claude 3.5 Sonnet / Cursor / GitHub Copilot)
- **Mission:**
    - Receive job assignment slip (Job Brief).
    - Write code (Build).
    - Report results.
- **Personality:** Diligent, disciplined, excellent coding skills but needs clear instructions.