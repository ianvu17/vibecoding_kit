# 00_Overview: Vibecode Overview

## Objectives
- Standardize collaboration between Humans (Project Owners) and AI (Implementation Units).
- Transform abstract ideas into real products through rigorous control steps.
- Eliminate unorganized "trial and error" thinking.

## Target Users
- **Non-tech Founders:** Want to build an MVP without hiring a CTO.
- **Product Managers:** Want to prototype ideas quickly.
- **Creators:** Want to automate tasks (Automation/Agents).

## Three Pillars of Vibecode
1. **Role-playing:** Clear role separation (Owner - Contractor - Executor).
2. **Documentation-First:** Write documentation (Blueprint) before writing code.
3. **Modularization:** Break down to conquer.