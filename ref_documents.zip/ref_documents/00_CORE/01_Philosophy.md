#01_Philosophy: Philosophy "Don't code now"

## Golden rule
**"One hour of Blueprint design saves 10 hours of Bug fixing."**

## The 5-Step Lifecycle
1. **Intake:** Clarify requirements, context, and limitations.
2. **Blueprint (Design):** Draw architecture map, data flow, select technology.
3. **Contract:** Closing the scope, defining "Done" (Definition of Done).
4. **Build:** AI Worker performs coding based on drawings. Absolutely comply with Blueprint.
5. **Refine:** Test, fix and optimize.

## Gatekeeper mindset
Between each step there is a "Gate". You may not go through the back gate without completing the front gate.
- No Blueprint yet? -> Cannot Build.
- Haven't finalized the contract yet? -> Cannot Build.