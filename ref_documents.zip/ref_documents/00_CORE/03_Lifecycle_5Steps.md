# 03_Lifecycle: Detailed project life cycle

## Step 1: Intake
- **Action:** You chat with Mr. Thau.
- **Output:** File `INTAKE.md`.

## Step 2: Design (Blueprint)
- **Action:** Mr. Contractor analyzes Intake and proposes solutions.
- **Output:** File `BLUEPRINT.md`.
- **Note:** This is the most important file. It is a "treasure map".

## Step 3: Commit
- **Action:** Mr. Contractor lists specific tasks.
- **Output:** Files `CONTRACT.md` and `GATES.md`.

## Step 4: Construction (Build)
- **Action:**
    - Mr. Thau created `JOB-001`.
    - You copy `JOB-001` and throw it to Mr. Worker.
    - Mr. Worker returned the Code.
    - You save the Code into the project.
- **Repeat:** Repeat with JOB-002, JOB-003...

## Step 5: Acceptance (Refine)
- **Action:** You test the software.
- **Output:** Update `GATES.md` (Mark Done or record Bug).