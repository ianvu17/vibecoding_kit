# JOB-103 – Intake

## 1. Context

Vibecode Starter Kit v0.1 has been completed:

- Core repo:
  - docs/ (Overview, Playbook, Quickstart 7 days)
  - templates/, scripts/, examples/, prompts/
- Product:
  - PRODUCT_BRIEF.md
  - PACKAGES.md
  - SALES_PAGE_DRAFT.md (completely written, with [OWNER_TODO])

Currently:

- There is no specific **30-day launch plan**:
  - What to post, where and what day?
  - How is the livestream/mini-demo?
  - First sales / number of users target?
  - How to monitor & optimize?

## 2. Objective of JOB-103

In JOB-103, we want:

1. Design a **30-day Launch Plan** for the first batch of Vibecode Starter Kit.
2. Clear conventions:
   - Main channel: (eg: personal Facebook, Fanpage, Group, Zalo, Email...)
   - Content type: sharing, case study, behind the scenes dev, demo.
   - Number of livestream / mini-workshop / Q&A sessions.
3. Turn the Launch Plan into a **living document** in the repo:
   - Easy to edit,
   - Can be reused for future batches.

## 3. Scope

In JOB-103, Technicians will support:

- Create folders and files:
  - `product/launch/LAUNCH_30D_OVERVIEW.md`
  - `product/launch/CONTENT_CALENDAR_30D.md`
  - `product/launch/SOCIAL_POST_TEMPLATES.md`
  - `product/launch/LIVESTREAM_OUTLINES.md`
  - `product/launch/METRICS_CHECKLIST.md`
- Fill in the content **frame + specific suggestions**, enough for the Owner to:
  - Edit timeline & messages.
  - Add personal voice, own story.

Don't do:

- Do not assign a hard channel if the Owner has not finalized it (placeholder & suggestion will be left).
- Don't write too personal sales content, that part will be taken care of by the Owner later.

## 4. Desired Outputs (Deliverables)

- File set in `product/launch/`:
  - 01 Overview: overall launch strategy.
  - 01 30-day Content calendar (detailed enough to follow).
  - 01 set of post/social templates.
  - 01 set of livestream outline/mini-demo.
  - 01 checklist to track data & retro after launch.

## 5. Constraints

- Language: Vietnamese.
- Level of detail:
  - Specific enough so that if you're busy, just "look at the calendar and know what to do today".
  - But there is still room for the Owner to edit, not too rigid.
- Must be easy to reuse:
  - Can copy and edit for batch 2, 3...

## 6. Definition of "done" (Definition of Done)

- Owner opens `product/launch/LAUNCH_30D_OVERVIEW.md` and:
  - Understand which direction the 30-day strategy is going.
- Owner opens `CONTENT_CALENDAR_30D.md`:
  - See daily plans: topics, suggested channels, content types.
- There are templates for posts, livestreams, and checklists for measurement.