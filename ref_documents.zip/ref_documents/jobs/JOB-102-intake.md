# JOB-102 – Intake

## 1. Context & Objectives

Vibecode Starter Kit v0.1 has been completed:
- Docs (Overview, Playbook, Quickstart 7 days)
- Templates, scripts, examples, prompts
- Product/ already has a draft of Product Brief + Packages

Currently **there is no complete Sales Page**, only:
- Skeleton content, idea sections.

Objectives of JOB-102:
- Create a complete **Sales Page (landing)** for Vibecode Starter Kit:
  - Can be used for:
    - Website,
    - Blog posts,
    - Long Facebook/LinkedIn posts.
  - Written in Vietnamese, easy to switch to other channels.

Sales Page needs:
- Summarize the problem → solution → benefits.
- Clearly locate suitable objects.
- Introducing the Starter package (and hinting at Pro/Studio if necessary).
- Paving the way for the 30-day Launch Plan (JOB-103).

## 2. Scope

In JOB-102:
- The worker will:
  - Build **sales page file** in `product/` (eg `product/SALES_PAGE_DRAFT.md` or edit existing file if duplicate).
  - Write content **neutral/pro version**, not too personal but "ready to use" enough.
  - Set the `[OWNER_TODO]` so that you:
    - add personal stories,
    - add testimonial, bio, pricing finally.

Don't do:
- Do not finalize the price if the Owner has not finalized it.
- Do not write too many technical details (already in the docs).

## 3. Desired Outputs (Deliverables)

- 1 Sales Page file:
  - Has a clear structure, can be used immediately.
  - Copy to web/FB almost unchanged.
- The owner only needs:
  - Fill in `[OWNER_TODO]`.
  - Update prices, payment links.

## 4. Constraints

- Language: Vietnamese, style:
  - Clear, pragmatic, not "crude sales closing".
  - Keep space for Owner to add his own colors.
- Content consistent with Product Brief & Playbook.

## 5. Definition of "done" (Definition of Done)

- You can get the Sales Page file:
  - Paste on a landing page (Webflow/Notion/Blog) → turn into a sales page.
- Owner only needs 1-2 edits to be able to use it to launch the first batch.