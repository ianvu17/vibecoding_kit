# JOB JOB-301 – Vibecode Beta Launch #1

## 1. Context & Objectives

**Context:**
Vibecode Starter Kit has completed Phase 2 with:
- Complete engine (docs, templates, scripts, prompts)
- SaaS Replacer #1: Doc-to-Action (JOB-201) ✅
- SaaS Replacer #2: Asset-to-Funnel (JOB-202) ✅
- Funnel content generated from Vibecode ebook (7 emails + 10 social posts + 2 video scripts)

It's time for a closed beta launch to:
- Validate real market demand
- Collect feedback from early adopters
- Create short-term revenue to continue growing

**Goal:**
- Launch closed beta Vibecode Starter Kit v0.1 for 2 weeks
- Attract 20-50 people to register for the waiting list
- Convert 5-10 people into beta testers (can pay or exchange feedback)
- Validate the true value of the product through user feedback

## 2. Scope

**In scope:**
- Simple landing page setup (can use Carrd, Notion, or Google Form)
- Deploy email sequence (7 emails) to ConvertKit/Mailchimp
- Post 5-10 social posts from JOB-202 output
- Record 1-2 short videos from existing scripts
- Track basic metrics (signups, open rate, engagement)
- Collect feedback from beta testers

**Out of scope:**
- Paid ads
- Complex automation
- Add new features to workflows
- Redesign branding
- Build custom website

## 3. Desired Outputs (Deliverables)

| # | Deliverable | Description |
|---|-------------|-------|
| 1 | Landing Page | Simple page with headline, benefits, registration CTA |
| 2 | Email Automation | 7 emails setup in ConvertKit/Mailchimp, trigger when signup |
| 3 | Social Content | 5-10 posts scheduled on Facebook/LinkedIn/TikTok |
| 4 | Video Content | 1-2 short videos shot from scripts |
| 5 | Beta Packages | Vibecode Starter Kit v0.1 (docs + 2 workflows) ready to share |
| 6 | Feedback System | Form/process to collect feedback from beta testers |

## 4. Constraints

**Technology:**
- Use free/freemium tools (Carrd, ConvertKit free tier, Canva)
- No need to code custom website
- Content is available from JOB-202

**Time:**
- 2 weeks from start date
- Week 1: Setup landing page + email + social scheduling
- Week 2: Launch soft → track → iterate

**Resources:**
- 1 person (Landlord) is the main person
- AI assist for copywriting adjustments
- Budget: $0-50 for tools if needed

## 5. Success Metrics

| Metrics | Target | Stretch Goal |
|--------|--------|--------------|
| Email signups | 20 | 50 |
| Email open rate | 30% | 50% |
| Social engagement | 50 interactions | 100+ |
| Beta testers | 5 | 10 |
| Qualitative feedback | 3 testimonials | 5+ |

## 6. Definition of "done" (Definition of Done)

- [ ] Landing page live and can signup
- [ ] Email sequence works (can send 1 email upon signup)
- [ ] At least 5 social posts posted/scheduled
- [ ] At least 1 video recorded and posted
- [ ] Reach minimum 20 signups
- [ ] Collect at least 3 feedback from beta testers
- [ ] Write Case Study & Retro for JOB-301