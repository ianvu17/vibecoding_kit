## 6. Persona & Scenarios (STEP 1)

### Persona 1 – Saigon office worker (person often tasked with choosing a restaurant)
- Age: 24–35  
- Office in District 1–District 3–Phu Nhuan  
- Often go out drinking in teams of 4–8 people  
- Very afraid of "choosing the wrong restaurant" because of being criticized by colleagues  
- No time to read reviews  
- I just want the restaurant to be delicious - airy - reasonably priced  

### Persona 2 – Group of close friends (weekend gathering)
- Group of 3–6 people  
- Likes grilled food/hot pot/goat/seafood  
- Important vibe: sidewalk, airy, wide, not luxurious  
- Budget: 300k–550k/person  
- I want AI to give quick suggestions to avoid arguing about choosing a restaurant

---

### Scenarios (minimum 3)

#### Scenario 1 – The most realistic need
**User said:**  
“5 people, want to eat goat/buffalo, avoid pigs, clear sidewalk, District 3, about 500k per person, tonight 6pm.”

**AI needs to understand → slots structured:**  
- people: 5  
- prefer: goat, buffalo  
- avoid: pig  
- vibe: sidewalk, airy  
- area: District 3  
- budget: 400k–600k  
- time: 18:00 today  

**Expected output:** 3–4 most suitable shops + explanation.

---

#### Scenario 2 – Mentioning “review storm”
**User said:**  
"Friends say that restaurant X has been cursed a lot lately, can you still eat it?"

**Expected output:**  
AI reads review data → separates drama → gives FairScore → says:  
"Last week the restaurant had a service drama, but the food was still okay. If you prioritize delicious goat, you should still try it."

---

#### Scenario 3 – Find shops within radius
**User said:**  
“I'm in Phu Nhuan, looking for a chill place nearby that has Hanoi beer.”

**Expected output:**  
- Automatically detect location → take a radius of 3–5km  
- Filter chill vibe + Hanoi draft beer  
- Suggested 3 shops + map link