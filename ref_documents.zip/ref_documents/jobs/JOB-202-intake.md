#JOB-202 – Asset-to-Funnel Workflow

## 1. Context & Objectives

### 1.1. Background

The owner has a lot of long content (ebooks, book chapters, long articles, livestream transcripts), but:

- Difficult to repurpose consistently into multi-channel marketing content.
- There are many SaaS repurposes (turning a video/article into an email, post, script...), but:
  - Expensive,
  - Data is on another party's cloud,
  - Difficult to customize tone & system.

### 1.2. Target

Building a LocalAI "Asset-to-Funnel" workflow helps:

- Input: 1 long content file (docx/pdf/txt).
- Output:
  - 1 sequence of 5–7 nurturing emails (Email Funnel).
  - 5–10 social posts (caption + visual suggestions).
  - 1–2 short video scripts (30–90s) to drive traffic.

Requirements:

- Run with 1–2 CLI commands and you're done.
- Based on context "Owner = expert/creator", not agency.

---

## 2. Input & Output

### 2.1. Input

- Long content file:
  - Priority: `.docx`, `.pdf`, `.md`, `.txt`.
  - For example:
    - Chapter in the ebook "Children are 1 year older"
    - Script livestream Reset Body 30
    - Vibecode ebook (can be reused as case study later)

- Optional:
  - `user_context` (role, persona)
  - `funnel_goal` (sell ebook / pull into group / book 1:1 call)

### 2.2. Output

- `output/email_sequence.md`
  - 5–7 emails, each email has:
    - Subject
    - Preview line (1 sentence)
    - Body (divided into segments, with clear CTA)

- `output/social_posts.md`
  - 5–10 posts:
    - Suggested platforms (FB / TikTok / LinkedIn)
    - Captions
    - Visual suggestions (image/video ideas)

- `output/short_scripts.md`
  - 1–2 video scripts:
    - Hook (3–5s)
    - Main content (3 ideas)
    - Final CTA

---

## 3. Quality criteria

### 3.1. Email Sequence

- Have a clear flow: from getting acquainted → telling stories → digging deeper into problems → giving solutions → CTA.
- Do not oversell raw goods; keep the tone of "sharing - expert - sincere".
- Each email can still be understood when read independently, the whole chain has a flow.

### 3.2. Social Posts

- Don't just "summarize the content", but must:
  - Curious,
  - Click to react (comment, share),
  - Aim towards the target funnel (eg: "join group", "read full ebook").

### 3.3. Short Scripts

- Strong hook, hitting pain.
- Main content is easy to film with natural dialogue, no writing.
- CTA is clear, not too lengthy.

---

## 4. MVP scope (v1)

**In scope:**
- Only process **1 asset at a time** (1 input file → 1 funnel).
- Supports 1, maximum 2 personas (eg: women 25–45, health-conscious).
- No need for UI, running CLI is enough.
- Support: `.docx`, `.pdf`, `.txt` (`.md` nice-to-have).

**Out of scope:**
- Batch processing many files at the same time.
- Web UI or API endpoint.
- Automatically post to social media.
- A/B testing variants.

---

## 5. Binding

**Technology:**
- Can run on Owner's computer (Mac, Python 3.10+).
- Use the same stack as JOB-201 (PyYAML, pypdf, python-docx, OpenAI client).

**Time:**
- Running time: accept a few tens of seconds → a few minutes for documents of 5–20 pages.

**Resources:**
- Reuse code from JOB-201 when possible (extract_text, call_llm, load_config).

---

## 6. Definition of "DONE" for JOB-202 (MVP)

- [ ] There is a folder `examples/asset-to-funnel-workflow/` with all the files
- [ ] `asset2funnel.py` CLI works with `--help`
- [ ] Running a command produces 3 output files as desired
- [ ] Have 1 case study with real assets (ebook chapter or transcript)
- [ ] There is sample output stored in `output/`
- [ ] There is retro in `logs/JOB-202-log.md`

---

## 7. Use Cases & Detailed Criteria

### 7.1. Use Cases

1. **Personal Creator** wants to turn an ebook chapter → email sequence to nurture list.
2. **Coach/Consultant** wants to turn transcript of livestream session → social posts to attract traffic.
3. **Founder** wants to turn whitepaper/case study → short video scripts for promotion.
4. **Book writer** wants to create marketing materials from existing book content.

### 7.2. Detailed quality criteria

**Email Sequence:**
- [ ] Have enough 5-7 emails with flow logic
- [ ] Each email has Subject, Preview, Body, CTA
- [ ] Expert tone, no spam
- [ ] There is progression from awareness → interest → desire → action

**Social Posts:**
- [ ] There are enough 5-10 posts
- [ ] Each post suggests a suitable platform
- [ ] Caption has hook + value + CTA
- [ ] Clear, actionable visual suggestions**Short Scripts:**
- [ ] There are 1-2 scripts under 90 seconds
- [ ] Hook in the first 3-5 seconds must attract attention
- [ ] The content is spoken naturally, without reading the text
- [ ] Clear final CTA

---

*This Intake was created using the Vibecode Starter Kit framework.*