#JOB-201 – Dogfood Case Study #1
# "Doc-to-Action" – AI Workflow replaces SaaS PDF summaries & action plans

## 1. Context

The owner is building a long-term direction:
- Use AI workflow to replace/rebuild expensive SaaS services yourself.
- There are many ideas, but need **a real mini-product**, small scope, to:
  - Dogfood Vibecode Starter Kit Phase 2.
  - Create live case studies, proving the framework works in practice.
  - Can later be packaged into a "brick" in the LocalAI SaaS Replacer system.

Related assets/experience:
- Did a lot of work with documents: PDF translation, summary, analysis.
- Have experience with Translator/Prismy.
- Strength: turning knowledge in documents into applicable content (actions, shared scripts).

## 2. JOB-201 Objective

Create a small AI workflow, running locally, that allows:

- Input: 1 document file (preferred PDF/Docx, Vietnamese or English).
- Workflow:
  - Preprocessing → separating text.
  - Call LLM → generate 3 outputs:
    1. **Summary**: Concise, structured summary.
    2. **Action List**: Checklist of applicable actions.
    3. **Script Draft**: 3–5 minute script draft for video/voice sharing.
- Output:
  - `output/summary.md`
  - `output/action_list.md`
  - `output/script_draft.md`

Here is the possible mini-product:
- Used internally to learn & share,
- Later attached to Prismy/LocalAI SaaS Replacer as a "template workflow",
- Plays the role of **official case study** in Vibecode's docs.

## 3. Scope

In JOB-201, we DO:

- Design mini-repo/workflow structure for Doc-to-Action.
- Write a simple CLI script (or notebook) to run end-to-end (single command).
- Design prompts and configure LLM at a sufficient level.
- Write README + running instructions.
- Record case studies:
  - Choose a real document.
  - Run workflows.
  - Log and comment.

DO NOT do in JOB-201:

- Not optimizing cost/speed at production level.
- Don't do full web UI, just CLI or notebook.
- Do not create account, multi-user, billing systems.
- No complicated integration (Zapier, automatic email sending...) - leave the next phase.

## 4. Deliverables

- New folder (located in large system - specifically recommended by Architect):
  - For example: `examples/doc-to-action-workflow/` or private repo.
- Minimum files:
  - `README.md` – workflow description, running instructions.
  - `doc2action.py` or `workflow.ipynb` – main workflow.
  - `prompts/summary_prompt.md`, `prompts/action_prompt.md`, `prompts/script_prompt.md`.
  - `config.example.yaml` (if needed).
- 1 set of sample output in `examples_output/`.
- 1 case study paragraph (can be included in `docs/02_vibecode_playbook.md` or separate file).

## 5. Constraints

- Language: code/documentation prioritizes English/Vietnamese depending on the context, but README needs to be in Vietnamese.
- Workflow must be able to run on:
  - Owner's current personal device (MacBook Pro M1).
  - Does not require too heavy infrastructure setup.
- Must use **Vibecode Starter Kit**:
  - JOB-201 has full Intake, Blueprint, Contracts, Logs.
  - Use `vibe.py pack-architect` and `pack-coder` to work with Architect/Coder.

## 6. Definition of "Done" (Definition of Done)

JOB-201 is considered COMPLETED when:

- You can clone/copy mini-workflow, run command (or open notebook) → receive all 3 output files from 1 sample PDF.
- README is enough for another person (familiar with AI at a basic level) to setup & run.
- Log JOB-201 records at least:
  - 1 retro round (what you learned when using Vibecode).
  - 1 case study applied to real documents that the Owner is interested in.

## 7. Use cases & output criteria (additional STEP 1)

### 7.1. Main use cases for Doc-to-Action

1. **Read professional books/chapters → Personal action plan**
   - Materials: books/chapters on health, nutrition, lifestyle, mindset...
   - Output:
     - Summary: quickly grasp the main idea of the chapter.
     - Action list: steps to apply to life.
     - Script: 3–5 minute script to record a video to share.

2. **AI/tech paper/report → Action for product/project**
   - Documents: long articles/blogs about AI, workflow, digital products, marketing.
   - Output:
     - Summary: problem, solution, main insight.
     - Action list: "what needs to be done" checklist for the project (Prismy, LocalAI SaaS Replacer...).
     - Script: simple explanatory script to share back with the community.3. **Method document → Checklist of coaching/teaching**
   - Documents: reset method, coaching roadmap, working framework...
   - Output:
     - Summary: 3–5 part structure of the method.
     - Action list: checklist by week/session.
     - Script: opening for a workshop/webinar or method introduction video.

4. **Ebook whitepaper/long blog → Prepare content for personal channel**
   - Documents: free ebook, whitepaper, long blog.
   - Output:
     - Summary: essence of content.
     - Action list: list of video/post ideas.
     - Script: script for a typical video.

### 7.2. Quality criteria for 3 types of output

#### a) Summary (Structured summary)

- Faithful to the original document, not fabricated.
- Have a clear structure: heading H2/H3 for context, main idea, conclusion.
- Length ~20–30% of original content, but keeps enough points.
- Clear, easy-to-read language; keep important terminology, short explanations if necessary.
- At the end of the summary there is a section **"Key Insights"** (3–5 ideas).

#### b) Action List (Action Checklist)

- Each bullet is an action statement, starting with a verb.
- Grouped by topic/stage (Preparation – Practice – Assessment).
- Marked with importance level: ⭐ Must-do / ➕ Optional.
- Specific, measurable, linked to user context.
- Short enough to execute (10–25 items depending on the document), users know what to do this week/month.

#### c) Script Draft (Speaking script draft 3–5 minutes)

- Structure: Hook (opening) – 2–3 main ideas (body) – Conclusion + small action.
- Spoken language, short sentences, easy to read, can add pause suggestions.
- Target length ~400–700 words (3–5 minutes of speaking).
- Maintain the speaker's "voice": warm, sincere, not lectured.
- Stick closely to document content; mention the source or the author's main idea.