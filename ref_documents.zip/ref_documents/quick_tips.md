# Quick Start Guide - Vibecode Kit v2.0

## What do you need?

- ChatGPT (GPT-4) - be a "Contractor" (designer)
- Claude Code or Cursor - become "Mr. Worker" (write code)

---

## 3 Unique Steps

### Step 1: Assign work to Contractor

Open file `10_PROMPTS/01_master_prompt_architect.txt`, copy the entire file and paste it into ChatGPT.

Then tell ChatGPT:

```
I want to do [DESCRIBE YOUR PROJECT]
```

For example:
- "I want to make a landing page to sell online courses"
- "I want to make an order management dashboard"
- "I want to make a personal portfolio"

### Step 2: Browse Blueprint

ChatGPT will provide Blueprint (design) and Contracts (contract).

- Read it over to see if it makes sense
- If you need to fix it, say: "Edit part X to Y"
- If OK, say: "Approve, give me the order"

### Step 3: Transfer orders to the Worker

Copy "Card command" from ChatGPT and paste it into Claude Code/Cursor.

The worker will write the code. Finished!

---

## Important Tips

| Wrong | Yes |
|-----|-------|
| "Make me a beautiful website" | "Create a landing page to sell shoes, have a hero section, testimonials, pricing" |
| "Error correction" | "Buy Now button cannot be clicked" |
| "Remake" | "Change background color from white to light blue" |

---

## Supported Product Type

- `landing` - Landing page, sales
- `dashboard` - Control panel
- `docs` - Instructions
- `saas` - SaaS application
- `branding` - Portfolio, brand
- `app` - Web application
- `ui` - Component library

---

## When you encounter an error

1. **Error code?** → Copy the error, paste it to the Worker (Claude), say "Fix this error"
2. **Not the right idea?** → Go back to Thau (ChatGPT), say "I want to change..."
3. **Want more features?** → Talk to Bid, get a new card order

---

## Practical Examples

**You:** "I want to make a landing page for a coffee shop, with a menu, opening hours, and a reservation form"

**Bid (ChatGPT):** Present Blueprint with 5 sections: Hero, Menu, Hours, Booking Form, Footer

**You:** "OK, give me the order"

**Tender:** Give Coder Pack

**You:** Copy and paste into Claude Code

**Worker (Claude):** Write complete code

**Done!**

---

*Vibecode Kit v2.0 - Make AI your team*