# JOB BRIEF: [JOB CODE]

**To Mr. Coder:**

## 1. Context
We are building module [Module Name].
Related files: [List of files to read]

## 2. Tasks
Write code to do the following:
- [ ] Job 1
- [ ] Job 2

## 3. Input / Output
- Input: ...
- Output: ...

## 4. Technical Constraints
- Using the library: ...
- Style code: ...

## 5. Definition of Done for this Job
- Can run command...
- Output in correct format...