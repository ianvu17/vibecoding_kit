# GATES LOG - Project log

| Gate | Gate Name | Status | Completion date | Notes |
|-------|----------|-------------|-----------------|---------|
| 1 | Setup | DONE | 2023-10-01 | Env installed |
| 2 | Core MVP | PENDING | ... | ... |

## Changelog / Bugs
- [x] Bug 1: ... (Fixed)
- [ ] Bug 2: ...