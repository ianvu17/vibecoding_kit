# CONTRACT - Construction contract

## 1. Scope (Scope of work)
- [ ] Feature A
- [ ] Feature B

## 2. Out-of-Scope (Not doing)
- [ ] Feature C (to Phase 2)
- [ ] Mobile App (Web only)

## 3. Definition of Done (Completion standard)
- Code runs without syntax errors.
- Tested main functions.
- There is a README file with instructions for running.

## 4. Gates (Control Gates)
- Gate 1: Complete the skeleton.
- Gate 2: Complete core functions.
- Gate 3: Complete UI/UX.