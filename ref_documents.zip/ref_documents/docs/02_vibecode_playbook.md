# Vibecode Playbook

Instructions for operating Vibecode from A to Z. After reading this Playbook, you can apply the framework to any project.

---

## 1. What is this playbook used for?

**Playbook ≠ Overview**

- [Overview](01_overview.md) answered: "What is Vibecode?"
- **Playbook** answers: "How to make Vibecode properly?"

This playbook provides:
- Operating principles
- Step by step process
- Checklist to check yourself
- Tips from real combat

<!-- OWNER_TODO: Write 1–2 Playbook introduction paragraphs from a personal perspective. For example: "This playbook is the result of X months of working with AI, after Y failed projects and Z successful projects..." -->

[OWNER_TODO] Add a personal introduction to the journey of finalizing this Playbook.

---

## 2. Core principles of Vibecode

Vibecode is built on 5 principles:

### 2.1. Humans retain the right to architecture & decision

- **Scope** is defined by humans, not AI
- **Architecture** designed by humans (or approved if AI suggests)
- **Acceptance** is determined by humans as pass/fail

> AI is very good at "doing", but it should not be left to AI to "decide what to do".

### 2.2. AI constructs according to spec, not arbitrarily creative

- AI receives specific STEPs with clear acceptance criteria
- AI does not add features or refactor itself outside of scope
- If the spec is vague → AI asks again, does not guess

### 2.3. Subdivide for control

- Each large JOB → divided into many small STEPs
- Each STEP has its own acceptance GATE
- Fail early, fix early, don't let errors accumulate

### 2.4. Write first, do later

- Do not start coding without a clear Intake
- Do not assign AI work without Contracts
- "Writing = thinking" – the clearer you write, the more correct the AI gets

### 2.5. Log everything, retro regularly

- Each STEP is completed → log
- Each JOB is completed → do retro
- Experience today = capital for tomorrow

<!-- OWNER_TODO: Tell the story of "Vibecode 1.0 → 2.0": how did you start working with AI? What problem? How was Vibecode born? -->

[OWNER_TODO] Add a personal story about how these principles came to be.

---

## 3. Three-party roles: Owner – Architect – Coder

Vibecode clearly divides 3 roles:

### 3.1. Owner – Human

**Responsibilities:**
- Definition of JOB goals and scope
- Write or browse JOB Intake
- Review Blueprint before construction
- Acceptance of each GATE
- Final decision when there is conflict

**Don't do:**
- No code needed (unless you want it)
- No need to design each module in detail

**Mindset:**
> "I'm the one who sets and grades the tests, not the one who solves them."

### 3.2. Architect (Contractor) – AI designer

**Suitable tools:** ChatGPT, Claude (chat mode), Gemini...

**Responsibilities:**
- JOB Intake analysis
- Blueprint design (overall architecture)
- Divide into Contracts (STEP + GATE)
- Propose a solution, but the Owner approves

**Don't do:**
- No direct coding
- Do not decide the scope yourself

**Input:** Vibecode Architect Pack (Intake + Current Blueprint)
**Output:** Complete Blueprint + Contracts

### 3.3. Coder (Worker) – AI executes

**Suitable tools:** Claude Code, Cursor, GitHub Copilot...

**Responsibilities:**
- Receive Vibecode Coder Pack (1 specific STEP)
- Implement correct spec: create files, write code, edit code
- Report results
- Ask again if the spec is unclear

**Don't do:**
- Do not manually add features outside of STEP
- Do not refactor unrelated code yourself
- No architectural decisions

**Input:** Vibecode Coder Pack (1 STEP content)
**Output:** Completed code/file + short report

### Assignment summary table

| Activities | Owner | Architect | Coders |
|-----------|-----|-----------|-------|
| Scope definition | ✅ Decision | Consulting | - |
| Writing Intake | ✅ Write/Browse | Support | - |
| Blueprint Design | Browse | ✅ Design | - |
| Writing Contracts | Browse | ✅ Writing | - |
| Execute STEP | Monitoring | - | ✅ Do |
| GATE acceptance | ✅ Decision | - | Report |
| Logging | ✅ Record | - | - |

<!-- OWNER_TODO: Give a specific example of how you coordinated 3 roles in a real project. For example: "When making Translator Pro, I play the role of Owner, use ChatGPT as Architect, Claude Code as Worker..." -->

[OWNER_TODO] Add a practical case study about coordinating 3 roles.

---

## 4. Life cycle of a JOB (details)

Each JOB goes through 5 stages:```
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ 1. OPEN │ → │ 2. SET │ → │ 3. EXAM │ → │ 4. TEST│ → │ 5. CLOSED │
│ JOB │ │ DESIGN │ │ WORK │ │ COLLECTION │ │ JOB │
└──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘
    Owner Architect Coder Owner Owner
```

### Phase 1: Open JOB

**Implementer:** Owner

**Action:**
```bash
python scripts/vibe.py new JOB-XXX --title "Tên công việc"
```

**Output:**
- `jobs/JOB-XXX-intake.md` – Fill in the problem information
- `blueprints/JOB-XXX-blueprint.md` – Leave blank, Architect will fill in
- `contracts/JOB-XXX-contracts.md` – Leave blank, Architect will fill in
- `logs/JOB-XXX-log.md` – Keep a diary

**Completion criteria:**
- Intake has been completely filled out: context, goal, scope, constraints, definition of done

### Phase 2: Design

**Implementer:** Architect (AI) + Owner (approval)

**Action:**
```bash
python scripts/vibe.py pack-architect JOB-XXX
```
→ Copy output, paste into ChatGPT with master prompt Architect
→ Receive Blueprint + Contracts
→ Owner reviews and adjusts if necessary
→ Save to the corresponding file

**Completion criteria:**
- Blueprint clearly describes the architecture, main flow, and risks
- Contracts have enough STEP with clear GATE
- Owner has approved

### Phase 3: Construction

**Implementer:** Coder (AI)

**Action (repeat for each STEP):**
```bash
python scripts/vibe.py pack-coder JOB-XXX STEP-N
```
→ Copy output, paste into Claude Code with master prompt Coder
→ Let Claude execute
→ Review the results

**Completion criteria:**
- Code/file is created according to spec
- Coder reports what has been done

### Phase 4: Acceptance

**Implementer:** Owner

**Action:**
- Check GATE criteria in Contracts
- Pass → move to the next STEP
- Fail → ask the Coder to correct it

**Completion criteria:**
- All GATE passed
- Definition of Done in Intake has been reached

### Phase 5: Close JOB

**Implementer:** Owner

**Action:**
```bash
python scripts/vibe.py log JOB-XXX "Hoàn thành JOB, đóng"
```
→ Retro writing: what's good, what needs improvement
→ Update personal playbooks if necessary

**Completion criteria:**
- Log is fully recorded
- There are lessons to be learned

### Case study: Using Vibecode to build Vibecode Starter Kit itself

To give you a better idea, the Vibecode Starter Kit itself is built using the Vibecode framework itself, in exactly 5 stages:

**1. Open JOB & write Intake**

I opened JOB-001 with a very clear question: "How can I package the way I work with ChatGPT & Claude into a kit that anyone can use?" In Intake, I document context, scope, what *doesn't* work in v0.1.

**2. Blueprint Design**

As Owner, I worked with ChatGPT as Architect to map out:
- Repo structure (docs/, templates/, scripts/, examples/, prompts/…)
- 3 core documents: Overview, Playbook, Quickstart 7 days
- Big JOBs to do: JOB-001 → JOB-004 (engine), JOB-101 → JOB-103 (product & launch)

**3. Write Contracts & assign work to Coder**

From the Blueprint, I separate it into specific STEPs in `contracts/`:
- STEP-1: Create file frame
- STEP-2: Fill in neutral content, leaving [OWNER_TODO] for the personal part
- STEP-3: Check GATE before considering "Done"

Every time, I use `vibe.py` to pack a "Coder Pack" and send it to Claude as a worker.

**4. Construction & re-logging**

Claude executes each STEP: writing docs, creating templates, completing Sales Page, Launch Plan... After each JOB, I log: How well did JOB-00X work, what got stuck, where the Playbook needs to be adjusted.

**5. Retro & Improved Playbook**

Once the engine, product and launch system were finished with v0.1, I went back to updating the Playbook: adding specific examples from this very journey, adjusting the wording to be both technical enough and easy to use for non-coders.

**Result:** Not only do I have a "nice & working" repo, but I also have a **standard process** that can be applied to every future AI project – and so can you.

[OWNER_TODO: add screenshot or quote from real conversation if desired]

---

## 5. Step-by-step instructions

### 5.1. Write good JOB Intake

**Do:**
- Describe the context enough for outsiders to understand
- Define specific, measurable goals
- Clearly list "in scope" and "out of scope"
- Record constraints: tech stack, time, resources
- Write Definition of Done in checklist form

**Avoid:**
- Intake is too short, lacking context
- Vague goals: "do good", "improve performance"
- No clear scope → AI will expand arbitrarily
- Forgot to write down constraints → Architect's design is out of touch with reality**Reference template:** `templates/jobs/JOB-intake-template.md`

<!-- OWNER_TODO: Tell me a case of "Bad Intake vs Good Intake" from your experience. -->

[OWNER_TODO] Add an example comparing bad vs good Intake.

### 5.2. Blueprint design

**Do:**
- Start with a 2–3 sentence summary of the solution
- Draw the main flow (can use ASCII diagram)
- List components, modules, files
- Record risks and assumptions
- Take notes on important design decisions

**Avoid:**
- Blueprint is too detailed (that's Contracts' job)
- No main flow → difficult to visualize the whole
- Ignore risks → only know if there are problems during construction

**Tips:**
- Ask the Architect to draw the diagram first, then write the details
- If the JOB is small, the Blueprint can be very short (5–10 lines)

<!-- OWNER_TODO: Share a sample Blueprint from your real project. -->

[OWNER_TODO] Add practical Blueprint example.

### 5.3. Writing Contracts (STEP & GATE)

**Do:**
- Each STEP has 4 parts: Objectives, Related files, Technical requirements, GATE
- STEP should be small enough to be done in 30–90 minutes
- GATE must be able to measure: "run command X and see Y", "file Z exists"
- Arrange STEPs in logical order (foundations first, details later)

**Avoid:**
- STEP is too large (>2 hours) → difficult to debug if it fails
- Ambiguous GATE: "code is clean", "works properly"
- Does not list related files → Coder has to guess himself

**Sizing guide:**
| Complexity | Number of recommended STEPs |
|-------------|---------------------|
| Small task (simple script) | 2–3 STEPS |
| Medium feature (1 module) | 4–6 STEP |
| Large feature (many modules) | 7–10 STEP, or divided into multiple JOB |

<!-- OWNER_TODO: Tell about a time when you divided STEP inappropriately and the lesson you learned. -->

[OWNER_TODO] More lessons on how to divide STEP.

### 5.4. Work with Architects

**Process:**
1. Preparation: Intake is completely filled out
2. Run `pack-architect` to get the Architect Pack
3. Open ChatGPT, paste master prompt Architect (if not already)
4. Paste Architect Pack
5. Requirement: "Design Blueprint and Contracts for this JOB"
6. Review output, request adjustments if necessary
7. Copy to the corresponding file

**Tips:**
- If the Architect asks again → good, it means he is trying to understand
- Don't be afraid to ask to "split STEP X into 2 STEPs"
- Can use multiple conversation rounds to refine

<!-- OWNER_TODO: Tell about an interesting conversation with Architect AI. -->

[OWNER_TODO] Add conversation example with Architect.

### 5.5. Work with Coder

**Process:**
1. Preparation: Contracts are available and approved
2. Run `pack-coder JOB-XXX STEP-N` to get the Coder Pack
3. Open Claude Code in VS Code (repo is open)
4. Paste master prompt Coder + Coder Pack
5. Let Claude execute
6. Review results, check GATE
7. Pass → STEP next. Fail → requires correction

**Tips:**
- Do each STEP sequentially, do not send multiple STEPs at the same time
- After each STEP, check GATE immediately, don't let it accumulate
- If Claude asks again → answer clearly, or go back to edit Contracts

**When Coder makes mistakes:**
- Don't blame AI, review Contracts to see if they are clear
- Provide additional context if needed
- If the error is repeated → Blueprint may need to be corrected

<!-- OWNER_TODO: Tell about a time Claude made a mistake and how you handled it. -->

[OWNER_TODO] Add case studies when Coders make mistakes.

### 5.6. Log & Retro

**Log – Logging:**
```bash
python scripts/vibe.py log JOB-XXX "Mô tả ngắn gọn"
```

**When to log:**
- After each STEP is completed
- When faced with a problem, the decision is important
- When changing scope or approach

**Retro – Lesson learned:**

At the end of each JOB, answer 3 questions:
1. **What works well?** (Retain)
2. **What's not good?** (Improvement)
3. **Lessons learned?** (Remember)

Record retro at the end of the log file or separate file.

**Tips:**
- Log is concise, enough to read and understand later
- Honest retro, no blame
- Update personal playbook if there is new insight

<!-- OWNER_TODO: Share a real retro and the lessons you learned. -->

[OWNER_TODO] More real retro examples.

---

## 6. Quick checklist

### Before starting JOB

- [ ] Clearly defined goals and scope
- [ ] Created JOB with `vibe.py new`
- [ ] Completely filled Intake
- [ ] Tech stack and constraints defined
- [ ] Wrote Definition of Done

### While working

- [ ] Blueprint has been approved before construction
- [ ] Contracts have clear GATE for each STEP
- [ ] Do each STEP sequentially
- [ ] Check GATE immediately after each STEP
- [ ] Log after each important STEP
- [ ] Ask the Architect again if STEP is too large or unclear

### After completing JOB- [ ] All GATE passed
- [ ] Definition of Done reached
- [ ] Recorded JOB closing log
- [ ] Made retro
- [ ] Updated personal playbook (if there is new insight)

---

## 7. Customize Vibecode for your own project

Vibecode is a framework, not a law. You can customize:

### 7.1. Change tools

| Ingredients | Default | Can be replaced with |
|-----------|----------|-----------|
| File storage | Markdown in repo | Notion, Obsidian, Google Docs |
| CLI tool | `vibe.py` | Self-written script, Make, Just |
| Architect AI | ChatGPT | Claude, Gemini, local LLM |
| Coder AI | Claude Code | Cursor, Copilot, Aider |

### 7.2. Integrate with existing workflows

**GitHub Issues / Projects:**
- Each JOB = 1 Issue
- Each STEP = 1 Task in Issue
- Link to Intake/Blueprint file in Issue description

**Notion / Obsidian:**
- Use database/table for JOB list
- Link to Markdown file or embed content

### 7.3. Applies to non-code projects

Vibecode isn't just for code:

| Project type | Application example |
|--------------|---------------|
| Writing ebooks | JOB = 1 chapter, STEP = sections |
| Do a course | JOB = 1 module, STEP = lessons |
| Marketing campaigns | JOB = 1 campaign, STEP = deliverables |

**Principles remain the same:**
- Still have Intake (problem definition)
- Still have Blueprint (master plan)
- Still have STEP + GATE (split + acceptance)

<!-- OWNER_TODO: Tell about how you applied Vibecode to different projects: Translator, FloodWatch, Bep Nhan, ebook... -->

[OWNER_TODO] Add case studies applying Vibecode to different types of projects.

<!-- OWNER_TODO: Share how your personal playbook was customized. -->

[OWNER_TODO] Add customized personal playbook example.

---

## Case Studies – JOB-201: Doc-to-Action Workflow

### General context

- **JOB:** JOB-201 – Doc-to-Action Workflow
- **Goal:** Build a local mini-workflow to turn a long document into:
  - Structured summary,
  - Action Checklist is applicable,
  - Script Draft 3–5 minutes to record video/voice.

- **Reason for choosing:** The owner is pursuing the direction of "Local AI SaaS Replacer" - building small AI workflows to gradually replace expensive SaaS (for example, PDF summary apps, action plan creation apps, content scripting apps...).

- **Dogfood results:** 2 real-life case studies, proving the workflow works with both technical/strategy and tutorial/process content.

---

### Case Study #1 – LocalAI Whitepaper (Technical/Strategy Content)

**Documents:**

- Name: *Enrich AI Infrastructure Article*
- Type: Strategic Whitepaper on Local-First AI infrastructure, open source model analysis (DeepSeek, Qwen, Llama), inference techniques, and VibeCode philosophy.
- Format: PDF (`.pdf`)
- File: `input/Làm Giàu Bài Báo Hạ Tầng AI.pdf`

**Goal for using Doc-to-Action:**

- Extract the content of an article heavy on concepts & strategies.
- Turn this content into:
  - 1 easy-to-read summary,
  - 1 action checklist to implement the LocalAI roadmap,
  - 1 3–5 minute script to explain to non-technical people.

**Run command:**

```bash
python doc2action.py \
  "input/Làm Giàu Bài Báo Hạ Tầng AI.pdf" \
  --output-dir output/sample \
  --user-context "AI founder building local-first workflows để thay thế SaaS"
```

**Result:**

- *Summary*:
  - Maintain the main axis of the article: why AI infrastructure is important, infrastructure layers, LocalAI vs cloud logic.
  - Reorganize the content into 7 parts, highlighting 5 main key insights.
  - Full list of specific application projects (Prismy Translator, FloodWatch, Teacher AI, Author Engine).

- *Action List*:
  - Divided into 5 phases: Strategic Prep → Deployment → Workflow → Implementation → Security.
  - Each action begins with a strong verb (Analyze, Calculate, Select, Deploy...).
  - Clearly distinguish ⭐ (important) vs ➕ (nice-to-have).
  - There are specific instructions for each project type (translation, sensor data, education, writing).

- *Script Draft*:
  - Attractive hook, hitting pain points (cost, privacy, loss of control).
  - Clear 3-point structure, friendly tone.
  - Gentle CTA, not pushy.

**Comments:**

- This is a Doc-to-Action validation case in the context of **technical/strategic content**, many abstract concepts.
- Workflow is handled well: summary is not superficial, action list is not generic like "learn more...".

---

### Case Study #2 – Vibecode Ebook (Tutorial/Process Content)

**Documents:**- Name: *Vibecode-forAI* (ebook about Vibecode framework for AI)
- Type: Tutorial/process content.
- Format: Docx (`.docx`)
- File: `input/Vibecode-forAI.docx`

**Goal for using Doc-to-Action:**

- Test the capabilities of Doc-to-Action when applied to **the Vibecode document itself**:
  - Summarize the structure of the ebook,
  - Draw an action roadmap to deploy Vibecode,
  - Create a 3–5 minute script to introduce Vibecode to newcomers.

**Run command:**

```bash
python doc2action.py \
  "input/Vibecode-forAI.docx" \
  --output-dir output/vibecode-ebook \
  --user-context "AI founder teaching others how to work with AI using Vibecode framework"
```

**Result:**

- *Summary*:
  - Understand the 6 main structural parts of the ebook.
  - Highlight gets **5 key insights** about:
    - 3 roles: Owner – Architect – Coder,
    - The value of turning "meeting AI" into a repeatable process,
    - How Vibecode helps reduce copy/paste chaos.

- *Action List*:
  - Divided into **5 standard phases**: Setup → Design → Dev → Test → Release.
  - Each action starts with a verb, specific enough to go into real implementation.
  - There are notes about 3 spells: "CONFIRM SAVE", "CONFIRM DO", "CONFIRM DONE".

- *Script Draft*:
  - Hook is very "winning": click on the fact that **non-coders can still build AI products if they have the right framework**.
  - The body of the article is divided into 3 clear ideas:
    - Current problems (copy/paste, overload, no products),
    - Vibecode's 3-role & JOB solution,
    - Application examples (like Doc-to-Action).
  - The last CTA encourages listeners to "start with a small JOB" - true to Vibecode's spirit.

**Comments:**

- This is a "self-mirror" case study: using Doc-to-Action to **summarize, extract actions, write scripts** for Vibecode.
- Helps prove:
  - Vibecode is not just a framework to "build products for customers",
  - But also a tool for the owner to systematize his own knowledge.

---

### Actual value brought to the Owner

After running JOB-201 on these 2 documents, the Owner receives:

1. **Save time reading & writing notes:**
   - Instead of 2-3 hours reading + notes, it only takes ~30 seconds to run the workflow + 15 minutes to read the summary/action list.
   - Workflow automatically extracts key insights and main structure of the document.

2. **Immediate action frame:**
   - Action list clearly shows the steps to be done, clearly divided into phases.
   - After reading, you can start implementing.

3. **There is a script available to share:**
   - Script draft can be recorded in video or used as an opening for a sharing/Zoom session.
   - In particular, the Vibecode ebook script is very suitable for introducing the framework to newcomers.

4. **Prove that the workflow can be used for many types of content:**
   - Technical/strategy content (LocalAI whitepaper).
   - Tutorial/process content (Vibecode ebook).

---

### Vibecode lesson through JOB-201

From JOB-201, the Owner draws:

- **What Vibecode does well:**
  - Dividing STEP (1-6) helps not to be overwhelmed when building the workflow from scratch.
  - Clear Architect – Coder pair: Architect designs the prompt/structure, Coder implements the code.
  - Has Intake + Blueprint so the scope is clear, no feature creep.
  - Log + Case Study format is available to help document the journey easily and reusable.

- **Things to adjust in Playbook/Quickstart:**
  - Should add instructions for choosing "adequate" documents for the first dogfood session (10-30 pages).
  - Need to note more clearly about setting up API keys and dependencies.
  - You can add 1-2 screenshots to illustrate the Doc-to-Action step.

- **Ideas for the next SaaS replacer workflows:**
  - JOB-202: Workflow converting webinar transcript → course outline + quiz.
  - JOB-203: Workflow converting ebook chapter → email sequence drip campaign.
  - JOB-204: Workflow converts meeting notes → action items + follow-up emails.

---

## Mini Checklist – When opening a new JOB for a SaaS Replacer Workflow (JOB-20X)

This Checklist is used for JOBs like JOB-201, when the Owner wants to build a small AI workflow to replace/reduce dependency on a specific SaaS.

### 1. Before opening a JOB (Pre-JOB)

- [ ] Identify **1 specific SaaS** you want to replace or "clone local".
  - For example: PDF summary app, email writing app, social scheduling app...
- [ ] Write 2–3 lines:
  - What problem is this SaaS solving for me?
  - Pain points when using that SaaS (price, limits, data, speed...).
- [ ] Select 1–2 **real use cases** (real documents, real workflows being used).

### 2. Intake & Blueprint- [ ] Create `JOB-20X-intake.md`:
  - Clearly **Input → Output**.
  - Clear MVP scope (only 1 stream, 1 input type first).
- [ ] Note clearly:
  - "Usability" criteria: in 1–2 sentences.
  - Constraints (machine, API, time, token).
- [ ] Create `JOB-20X-blueprint.md`:
  - Folder structure.
  - Main stream (diagram ASCII or bullet steps).

### 3. During build (Coding & Orchestrator)

- [ ] Divide tasks clearly to Architect – Coder:
  - Architect takes care of prompts, flow, interface.
  - Coder takes care of code, error handling, README.
- [ ] Keep the thread running **a single command** (CLI or notebook cell) for the first MVP.
- [ ] Always have:
  - `config.example.yaml`
  - `requirements.txt`
  - `README.md` with "How to run in 5 minutes".

### 4. After having MVP (Dogfood)

- [ ] Run **at least 1 real document** (not "Hello World").
- [ ] Save:
  - Sample input (or description).
  - 3–4 representative output (sample).
- [ ] Mark:
  - 3 things workflow does well.
  - 3 things to improve.

### 5. Logging & Retro

- [ ] Updated `logs/JOB-20X-log.md` with:
  - Running day,
  - Command used,
  - Feel.
- [ ] Write a short Retro:
  - What went well?
  - What could be better?
  - Next actions (1–3 specific things).

### 6. Prepare for productize phase (optional)

- [ ] Note: This workflow **is suitable for which user groups**?
- [ ] 1–2 ideas:
  - Make UI simple?
  - Plug into Prismy/LocalAI platform?
  - Used as a mini-product for sale?

---

## Conclusion

This playbook is a starting point. You will develop your own playbook through real combat.

Most important principle: **Vibecode helps you master AI, not let AI master you.**

<!-- OWNER_TODO: Write a personal conclusion. -->

[OWNER_TODO] Write a conclusion in your own style.

---

*See more: [Overview](01_overview.md) | [Quickstart 7 days](03_quickstart_7_days.md)*