# References

This folder contains advanced material for those who want to learn more deeply.

**You do NOT need to read anything here to use Vibecode Kit.**

Just using .txt files in the root directory is enough.

## Content

- `00_CORE/` - Philosophy and principles
- `10_PROMPTS/` - Original prompt templates
- `20_TEMPLATES/` - Document template
- `30_EXAMPLES/` - Reference example
- `40_TOOLS/` - Support tool
- `skills/` - Detailed UI/UX Guidelines
- `legacy/` - Old version (MOTHER-PROMPT)