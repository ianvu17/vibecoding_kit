# Quick Commands (Quick Commands for Mr. Contractor)

Copy these commands and paste them into ChatGPT for quick control:

- `/status`: What stage is the project report at? What to do next?
- `/blueprint`: Let's create content for the BLUEPRINT.md file based on what was discussed.
- `/job [tên tính năng]`: Please write a Job Brief (Coder Prompt) so I can give it to Mr. Mechanic to create this feature.
- `/fix`: Mr. Craftsman has this error [paste error], please analyze and rewrite the instructions for Mr. Craftsman.
- `/review`: Re-evaluate the current architecture, are there any risks?