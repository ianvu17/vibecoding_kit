# JOB JOB-001 – Blueprint

## 1. Summary

Create a CLI tool in Python to standardize image file names in a directory:
- Convert everything to lowercase
- Replace spaces and special characters with dashes `-`
- Keep the extension intact

## 2. Main Flow

```
[User chạy script] → [Scan folder] → [Filter image files] → [Generate new names] → [Rename files] → [Log kết quả]
```

**Details:**
1. Running user: `python rename_images.py /path/to/images`
2. Script scan folder, get list of image files (.jpg, .png, .gif, .webp)
3. For each file:
   - Get file name (no extension)
   - Convert to lowercase
   - Change spaces → `-`
   - Change special characters → `-`
   - Remove redundant `-` (beginning, ending, consecutive)
4. Check for duplicate names → add suffix if necessary
5. Perform rename
6. Log to screen: `old_name → new_name`

## 3. Components & Related Files

| Ingredients | Description | File/Path |
|-------------|-------|-----------|
| Main script | Logic rename | `rename_images.py` |
| README | Instructions for use | `README.md` |

## 4. Risks & Assumptions

**Risks:**
| Risk | Level | How to reduce |
|--------|--------|-----------------|
| Same name after rename | Average | Add suffix `-1`, `-2` |
| File in use | Low | Report error, skip, continue |

**Assumption:**
- User has write rights in the directory
- File name is not too long (< 255 characters)

## 5. Additional notes

- Use `pathlib` instead of `os.path` for cleaner code
- Use `argparse` for CLI interface