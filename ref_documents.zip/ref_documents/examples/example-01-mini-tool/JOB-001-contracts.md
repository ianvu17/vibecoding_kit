# JOB JOB-001 – Contracts

## STEP 1 – Setup project structure and CLI skeleton

**Goal:**
- Create file `rename_images.py` with basic CLI interface
- Can run `--help` and receive path from argument

**Related files:**
- `rename_images.py`

**Technical requirements:**
- Use `argparse` for CLI
- Receive 1 positional argument: `directory`
- There is an option `--dry-run` to only preview, not actually rename
- Validate directory exists

**Acceptance criteria (GATE 1):**
- [x] Run `python rename_images.py --help` to display usage
- [x] Run with path that does not exist → clear error message
- [x] Run with valid path → no crash

---

## STEP 2 – Implement scan and filter logic

**Goal:**
- Scan folders and filter out image files
- Log list of found files

**Related files:**
- `rename_images.py`

**Technical requirements:**
- Use `pathlib.Path.glob()` to scan
- Filter extensions: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp` (case-insensitive)
- Only takes files, not directories

**Acceptance criteria (GATE 2):**
- [x] Run with a folder with 5 image files → list out exactly 5 files
- [x] Ignore non-image files (.txt, .pdf)
- [x] Ignore subfolders

---

## STEP 3 – Implement name transformation logic

**Goal:**
- Write a function that converts file names according to rules

**Related files:**
- `rename_images.py`

**Technical requirements:**
- Function: `normalize_name(filename: str) -> str`
- Convert lowercase
- Change spaces → `-`
- Replace special characters (not a-z, 0-9, -) → `-`
- Remove `-` at the beginning and end
- Merge multiple consecutive `-` into 1

**Acceptance criteria (GATE 3):**
- [x] `"My Photo.jpg"` → `"my-photo.jpg"`
- [x] `"image@2x.png"` → `"image-2x.png"`
- [x] `"---test---.jpg"` → `"test.jpg"`

---

## STEP 4 – Implement rename and handle duplicate names

**Goal:**
- Perform file rename
- Handling cases of duplicate names

**Related files:**
- `rename_images.py`

**Technical requirements:**
- If new name already exists → add suffix `-1`, `-2`, ...
- Use `Path.rename()` to change name
- Log: `✓ old_name → new_name`
- If the name does not change → skip, log `- filename (không đổi)`

**Acceptance criteria (GATE 4):**
- [x] Rename files successfully
- [x] No file loss
- [x] Correctly handle duplicate names

---

## STEP 5 – Implement dry-run mode and README

**Goal:**
- Complete `--dry-run` mode
- Write README instructions

**Related files:**
- `rename_images.py`
- `README.md`

**Technical requirements:**
- `--dry-run`: only log preview, not actual rename
- README has:
  - Tool description
  - How to install (requires Python)
  - Usage with examples
  - Options

**Acceptance criteria (GATE 5):**
- [x] `--dry-run` does not change the actual file
- [x] README full of information
- [x] Successfully run full flow