# JOB JOB-001 – Intake

## 1. Context & Objectives

**Context:**
The team has many image files in the `images/` folder with non-standard names:
- With spaces: `My Photo.jpg`
- Special character: `image@2x.png`
- Mixed capitalization: `BannerHero.PNG`

This causes an error when deploying to the web server.

**Goal:**
Create a Python script to rename all image files in standard format: `lowercase-with-dashes.ext`

## 2. Scope

**In scope:**
- Handles formats: .jpg, .jpeg, .png, .gif, .webp
- Run from CLI with directory path parameter
- Log to the screen the renamed files
- Handling duplicate names (add suffix `-1`, `-2`, ...)

**Out of scope:**
- Does not process subfolders (only root folder)
- No video processing
- No GUI

## 3. Desired Outputs (Deliverables)

| # | Deliverable | Description |
|---|-------------|-------|
| 1 | `rename_images.py` | Runable Python script |
| 2 | `README.md` | Instructions for use in the script folder |

## 4. Constraints

**Technology:**
- Python 3.8+
- Only use standard libraries (os, pathlib, re, argparse)
- Do not overwrite the file if the new name already exists

**Time:**
- Completed in 1 session

**Resources:**
- 1 developer + Claude Code

## 5. Definition of "done" (Definition of Done)

- [x] Script runs without errors with test folder
- [x] All files are renamed in the correct format
- [x] No files lost
- [x] There is a README for instructions