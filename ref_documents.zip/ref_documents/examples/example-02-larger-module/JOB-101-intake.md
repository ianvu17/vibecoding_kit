# JOB JOB-101 – Intake

## 1. Context & Objectives

**Context:**
The current e-commerce system does not have an API for product management. The mobile team needs API to build the app. Currently using Django + PostgreSQL.

**Goal:**
Build REST API module to CRUD products (Product) with features:
- List, search, filter products
- Create, edit, delete products (admin only)
- Pagination

## 2. Scope

**In scope:**
- Model: Product (name, description, price, category, image_url, status)
- API endpoints: GET /products, GET /products/:id, POST /products, PUT /products/:id, DELETE /products/:id
- Filter: by category, by status, by price range
- Search: by name
- Pagination: limit/offset
- Authentication: JWT (already available in the system)
- Permission: view = all, create/update/delete = admin

**Out of scope:**
- Model Category (use simple string)
- Image upload (only save URL)
- Inventory management
- Cart integration

## 3. Desired Outputs (Deliverables)

| # | Deliverable | Description |
|---|-------------|-------|
| 1 | Model Product | Django model with migration |
| 2 | Serializers | DRF serializers for Product |
| 3 | ViewSet | API endpoints with filter/search/pagination |
| 4 | Tests | Unit tests for API |
| 5 | API Docs | OpenAPI/Swagger documentation |

## 4. Constraints

**Technology:**
- Django 4.x, Django REST Framework 3.x
- PostgreSQL (installed)
- Follow existing code style in project
- Use django-filter for filtering

**Time:**
- Completed in 2-3 sessions

**Resources:**
- 1 developer + ChatGPT (architect) + Claude (coder)

## 5. Definition of "done" (Definition of Done)

- [x] All endpoints work properly
- [x] Permission is correct (admin-only for write operations)
- [x] Tests coverage > 80%
- [x] API docs are viewable
- [x] Code review passed