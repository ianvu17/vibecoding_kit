# JOB JOB-101 – Blueprint

## 1. Summary

Build REST API module for Product management in Django e-commerce system. This module will reside in app `products/` and expose endpoints according to RESTful convention.

## 2. Main Flow

```
[Client Request] → [JWT Auth] → [Permission Check] → [ViewSet] → [Serializer] → [Model] → [Database]
                                                                                    ↓
[Client Response] ← [Serializer] ← [ViewSet] ←──────────────────────────────────────┘
```

**Details:**
1. Client sends request with JWT token
2. Token authentication middleware (already available)
3. ViewSet checks permissions
4. ViewSet calls Serializer to validate/transform data
5. Serializer interacts with Model
6. Model performs database operations
7. Response returned via Serializer → ViewSet → Client

## 3. Components & Related Files

| Ingredients | Description | File/Path |
|-------------|-------|-----------|
| Model | Product model | `products/models.py` |
| Serializer | CRUD serializers | `products/serializers.py` |
| ViewSet | Logical API | `products/views.py` |
| URLs | Route config | `products/urls.py` |
| Filters | Filter classes | `products/filters.py` |
| Tests | API tests | `products/tests/` |
| Admin | Admin interface | `products/admin.py` |

**Folder structure:**
```
products/
├── __init__.py
├── models.py
├── serializers.py
├── views.py
├── urls.py
├── filters.py
├── admin.py
├── migrations/
└── tests/
    ├── __init__.py
    ├── test_models.py
    ├── test_serializers.py
    └── test_views.py
```

## 4. Risks & Assumptions

**Risks:**
| Risk | Level | How to reduce |
|--------|--------|-----------------|
| Conflict with existing code | Average | Review carefully before merging |
| Performance when the list is large | Low | There is pagination, add index after |
| JWT integration issues | Low | Reusing existing auth system |

**Assumption:**
- JWT authentication has been setup and working
- PostgreSQL is available and can be connected
- User model has field `is_staff` to check admin

## 5. Additional notes

**API Response Format:**
```json
{
  "count": 100,
  "next": "http://api/products/?offset=20",
  "previous": null,
  "results": [...]
}
```

**Product Status Options:**
- `draft`: Not yet published
- `active`: On sale
- `archived`: Stopped selling