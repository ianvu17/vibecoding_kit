# JOB JOB-101 – Contracts

## STEP 1 – Setup app structure and Model

**Goal:**
- Create Django app `products`
- Define Product model with fields according to spec
- Create and run migrations

**Related files:**
- `products/__init__.py`
- `products/models.py`
- `products/admin.py`
- `products/apps.py`
- `settings.py` (add to INSTALLED_APPS)

**Technical requirements:**
- Product Model:
  - `name`: CharField(max_length=255)
  - `description`: TextField(blank=True)
  - `price`: DecimalField(max_digits=10, decimal_places=2)
  - `category`: CharField(max_length=100)
  - `image_url`: URLField(blank=True)
  - `status`: CharField with choices (draft, active, archived)
  - `created_at`, `updated_at`: auto timestamp
- Register in admin with list_display and filters

**Acceptance criteria (GATE 1):**
- [ ] `python manage.py makemigrations` no error
- [ ] `python manage.py migrate` success
- [ ] Product can be created via Django admin
- [ ] Fields display correctly in admin

---

## STEP 2 – Serializers and basic ViewSet

**Goal:**
- Create ProductSerializer
- Create ProductViewSet with basic CRUD
- Config URLs

**Related files:**
- `products/serializers.py`
- `products/views.py`
- `products/urls.py`
- `config/urls.py` (include products urls)

**Technical requirements:**
- ProductSerializer with all fields
- ProductViewSet inherits ModelViewSet
- Register with DefaultRouter
- Include in main urls with prefix `/api/products/`

**Acceptance criteria (GATE 2):**
- [ ] GET `/api/products/` returns list
- [ ] GET `/api/products/:id/` returns details
- [ ] POST `/api/products/` successfully created
- [ ] PUT `/api/products/:id/` updated successfully
- [ ] DELETE `/api/products/:id/` deleted successfully

---

## STEP 3 – Filtering and Search

**Goal:**
- Implement filter by category, status, price range
- Implement search by name
- Add pagination

**Related files:**
- `products/filters.py`
- `products/views.py`

**Technical requirements:**
- Use `django-filter` with FilterSet
- Filters:
  - `category`: exact match
  - `status`: exact match
  - `price_min`, `price_max`: range filter
- Search: `search` param search in `name`
- Pagination: LimitOffsetPagination, default limit=20

**Acceptance criteria (GATE 3):**
- [ ] `/api/products/?category=electronics` filter is correct
- [ ] `/api/products/?status=active` filter is correct
- [ ] `/api/products/?price_min=100&price_max=500` filter is correct
- [ ] `/api/products/?search=phone` found the correct one
- [ ] Response has `count`, `next`, `previous`, `results`

---

## STEP 4 – Permissions

**Goal:**
- Implement permission: read = all, write = admin only

**Related files:**
- `products/permissions.py`
- `products/views.py`

**Technical requirements:**
- Custom permission class `IsAdminOrReadOnly`
- Anonymous user: GET only
- Authenticated non-admin: GET only
- Admin (is_staff=True): full CRUD
- Apply to ViewSet

**Acceptance criteria (GATE 4):**
- [ ] Anonymous GET → 200 OK
- [ ] Anonymous POST → 401 Unauthorized
- [ ] Normal user POST → 403 Forbidden
- [ ] Admin POST → 201 Created

---

## STEP 5 – Unit Tests

**Goal:**
- Write tests for model, serializer, and API

**Related files:**
- `products/tests/__init__.py`
- `products/tests/test_models.py`
- `products/tests/test_serializers.py`
- `products/tests/test_views.py`

**Technical requirements:**
- Test model: create, validate
- Test serializer: valid/invalid data
- Test views:
  - List, detail, create, update, delete
  - Filter, search, pagination
  - Permissions
- Use pytest and pytest-django
- Factory Boy for test data

**Acceptance criteria (GATE 5):**
- [ ] `pytest` pass all tests
- [ ] Coverage > 80%
- [ ] No test skip/xfail

---

## STEP 6 – API Documentation

**Goal:**
- Setup drf-spectacular for OpenAPI docs
- Verify docs display correctly

**Related files:**
- `settings.py`
- `config/urls.py`

**Technical requirements:**
- Install and configure `drf-spectacular`
- Add endpoints:
  - `/api/schema/` - OpenAPI schema
  - `/api/docs/` - Swagger UI
- Verify all endpoints display correctly

**Acceptance criteria (GATE 6):**
- [ ] `/api/docs/` displays Swagger UI
- [ ] All endpoints are in the docs
- [ ] API can be tested from Swagger UI