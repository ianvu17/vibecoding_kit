# Doc-to-Action Workflow

Mini-workflow uses AI to turn a document (PDF/Docx) into:
- **Summary**: concise, structured summary.
- **Action List**: applicable action checklist.
- **Script Draft**: draft a 3–5 minute speaking script.

## 1. Quick installation

### 1.1. Install dependencies

```bash
pip install -r requirements.txt
```

Or install manually:

```bash
pip install pyyaml pypdf python-docx openai
```

### 1.2. Create config file

```bash
cp config.example.yaml config.yaml
```

Adjust `config.yaml` according to the model you want to use.

### 1.3. Set API key

```bash
export OPENAI_API_KEY="your-api-key-here"
```

## 2. How to run

### Basic running method

```bash
python doc2action.py input/your-document.pdf
```

### With options

```bash
python doc2action.py input/your-document.pdf \
    --config config.yaml \
    --output-dir output \
    --user-context "health coach building a 4-week program"
```

### See help

```bash
python doc2action.py --help
```

## 3. Output

After running, you will have 3 files in the `output/` folder:

| File | Description |
|-------|-------|
| `summary.md` | Structured summary, 3-5 key insights |
| `action_list.md` | Checklist of actions by phases (⭐ Must-do / ➕ Optional) |
| `script_draft.md` | 3-5 minute speaking script (Hook → Main → Takeaway) |

## 4. Directory structure

```text
examples/doc-to-action-workflow/
├── README.md
├── doc2action.py # Main CLI script
├── config.example.yaml # Template config
├── config.yaml # Real Config (gitignore)
├── requirements.txt # Python dependencies
├── prompts/
│ ├── summary_prompt.md
│ ├── action_prompt.md
│ └── script_prompt.md
├── input/
│ └── (put your PDF/Docx here)
└── output/
    ├── summary.md
    ├── action_list.md
    └── script_draft.md
```

## 5. Use cases

1. **Read professional books/chapters → Personal action plan**
   - Input: books about health, nutrition, mindset
   - Output: summary + application checklist + shared script

2. **AI/tech paper/report → Action for the project**
   - Input: articles about AI, workflow, digital products
   - Output: summary + checklist for project + explanatory script

3. **Method document → Checklist coaching**
   - Input: framework, roadmap, methods
   - Output: summary + weekly checklist + workshop script

4. **Ebook/whitepaper → Content for personal channel**
   - Input: free ebook, long blog
   - Output: summary + content ideas + video script

## 6. Config options

See `config.example.yaml` for options:

- `llm_provider`: now supports `openai`
- `model_name`: model to use (eg: `gpt-4.1-mini`)
- `max_tokens`: output limit
- `temperature`: creativity (0.0 - 1.0)

## 7. Notes

- This workflow is built with **Vibecode Starter Kit**.
- Refer to `jobs/JOB-201-intake.md` to see detailed use cases & quality criteria.
- Prompts can be customized in `prompts/*.md`.