# Vibecode Beta Landing – Final Copy

> This copy is written according to Vibecode Design System (Apple-inspired).
> Tone: expert, sharing, not pushy, minimalist.
> Paste directly into Carrd/Notion.

---

## HERO SECTION

### Headline
```
Vibecode Beta Circle
```

### Subheadline
```
2 weeks of building your own AI workflow.
No need to know code.
```

### Body (2-3 lines)
```
A closed beta program for people who want to turn ideas into real AI products – by working with AI, not learning code.

You'll get a framework, prompts, and step-by-step instructions. I'll be with you for 2 weeks.
```

### CTA Buttons
- Primary: `Đăng ký tham gia Beta`
- Secondary (link): `Xem Vibecode làm được gì`

---

## SECTION 1: What is Vibecode?

### Heading
```
Vibecode does not teach you to code.
Vibecode teaches you to work with AI.
```

### Body
```
Most people think: "If you want to be an AI, you must know how to program."

Actually that is not the case.

With the right approach, you can:
• Generate ideas and decisions (role of "Host")
• Let AI design and test (role "Architect")
• Let another AI write code according to instructions (role "Builder")

You don't code. You manage.
Vibecode is the framework that helps you do that.
```

---

## SECTION 2: What do you get in 2 weeks of Beta?

### Heading
```
In 2 weeks, you will have:
```

### List (using Lucide icon: Package, FileText, MessageSquare, Users)
```
[Package] Vibecode Starter Kit v0.1
The set of documents, templates, prompts have been tested with real case studies.

[FileText] 2 Workflow works now
• Doc-to-Action: Turn long document → summary + action list + script
• Asset-to-Funnel: Turn ebook/content → email sequence + social posts

[MessageSquare] Step-by-step instructions
7 nurturing emails, setup instructions from A-Z, don't give up halfway.

[Users] Beta Community
Small Zalo/Discord group for direct Q&A, sharing, and feedback.
```

---

## SECTION 3: For anyone / Not for anyone

### Layout: 2 columns

**Left column – For you if:**
```
• Have a product/service idea but don't know the code
• Want to automate work using AI
• Be willing to spend 30 minutes/day for 2 weeks
• Prefer practical work over theory
```

**Right column – Not suitable if:**
```
• Want to learn programming from the basics
• Need complex enterprise solutions
• No testing period
• Just want to "see" but don't do it
```

---

## SECTION 4: How it works

### Heading
```
Simple process, real results
```

### Timeline (vertical, use Lucide icon: Download, Wrench, Rocket)
```
[Download] Week 0
Register → Get Starter Kit → Join the community

[Wrench] Week 1
Set up the environment → Run the first workflow → Get real output

[Rocket] Week 2
Customization for specific use cases → Feedback → Next steps
```

---

## SECTION 5: About me

### Heading
```
Who is behind Vibecode?
```

### Body (brief)
```
I'm [Name], I've spent 2 years experimenting with how to work with AI without learning to code.

Vibecode is what I use to build products, create content, and automate daily tasks – distilled into a passable framework.

This is not a course. This is the tool + companion.
```

### Social proof (if any)
```
"Tested with 2 real case studies before opening beta."
```

---

## SECTION 6: Registration form

### Heading
```
Join Vibecode Beta Circle
```

### Subtext
```
Fill in the information below. I will send a confirmation email and follow-up instructions within 24 hours.
```

### Form fields
```
Email *
[input field]

What do you want to use Vibecode for? (optional)
[textarea - 2 lines]

[Button: Register now]
```

### Privacy note (small, under the button)
```
Your information is confidential. No spam. You can unsubscribe at any time.
```

---

## FOOTER (minimal)

```
Vibecode © 2025
```

---

## NOTES FOR CARRD SETUP### Colors
- Page background: `#F5F5F7`
- Card/Section: `#FFFFFF`
- Text primary: `#0B0F19`
- Text secondary: `#4B5563`
- Accent (button): `#2563EB`

### Typography
- Let Carrd use system font (sẽ auto SF Pro trên Mac)
- Heading: Bold/Semibold
- Body: Regular

### Spacing
- Generous padding between sections
- Cards should have internal padding

### Form
- Connect to ConvertKit/Mailchimp
- Set up automation trigger

---

## OPTIONAL: OG Meta Tags

```
Title: Vibecode Beta Circle – Xây workflow AI không cần code
Description: 2 tuần framework + hướng dẫn + cộng đồng. Biến ý tưởng thành sản phẩm AI thực sự.
Image: [Hero image với logo Vibecode]
```

---

*Copy này đã optimize cho conversion + Apple aesthetic.*
*Tone: Expert sharing, not selling.*