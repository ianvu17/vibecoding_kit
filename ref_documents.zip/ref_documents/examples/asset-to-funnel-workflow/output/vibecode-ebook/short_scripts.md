## Script 1: AI Builds Products Without Code? This Is Standard Procedure!

**Duration**: ~60 seconds  
**Platform**: TikTok / Reels / YouTube Shorts  
**Style**: Talking head + Text overlay

### Hook (0-5 seconds)  
Stop messing things up if you want to build an AI product without knowing how to code!

### Main Content (5-45 seconds)  

**Point 1**:  
You only need 3 characters in the AI project: You - the Homeowner, the AI Assistant (ChatGPT) - the Architect, and the Builder (Claude Code) - the code writer. You just need to say your idea, the AI ​​Assistant will ask for clarification, draw the design, and then send instructions to the Builder.

**Point 2**:  
The process is extremely simple: you describe the idea → the assistant asks 5 important questions → create a design → you approve → instruct the builder → receive a report → check and fix errors until finished.

**Point 3**:  
You don't need to know code, just focus on managing, making decisions, and tracking progress. AI helps you gather ideas, create checklists, and remind you to remember your progress every day. AI projects are no longer difficult!

### CTA (45-60 seconds)  
Want to build an AI product without coding? Register now to receive Vibecode Starter Kit v0.1 and get on the waiting list for detailed instructions on this process!

---

**Visual Notes**:  
- Front camera, good lighting, confident expression  
- Text overlay for each role: “Friend - Homeowner”, “AI Assistant - Architect”, “Builder - Claude Code”  
- Highlight effect when saying "5 important questions", "blueprint", "builder's guide"  
- At the end of the video, a registration button or suggestion link appears  

**Audio Notes**:  
- Modern background music, moderate energy, does not overwhelm the voice  
- Clear, friendly tone, emphasizing each easy-to-understand step  

**Caption for Post**:  
If you don't know how to code, you can still build AI? This is the process you need! Get the Vibecode Starter Kit now! #AI #NoCode #Vibecode

---

## Script 2: 3 Roles to Help You Build AI Products Without Code

**Duration**: ~60 seconds  
**Platform**: TikTok / Reels / YouTube Shorts  
**Style**: Talking head + Animated text overlay

### Hook (0-5 seconds)  
Do you think to be an AI you must know how to code? Think again!  

### Main Content (5-45 seconds)  

**Point 1**:  
There are 3 roles you need: The host (you) just needs to talk about ideas and make decisions. AI assistant (ChatGPT) is the architect that helps you clarify ideas, create designs and checklists. Code Builder (Claude Code) is someone who writes code based on instructions.

**Point 2**:  
You don't code, you don't worry about debugging. You just need to approve the design, send instructions to the builder and check the results. The AI ​​assistant will help you ask the right questions, gather clear ideas, and remind you to remember your progress.

**Point 3**:  
This process helps you save time, avoid errors, and complete your AI product step by step with ease. Anyone can do it, even if they don't know how to code!

### CTA (45-60 seconds)  
Click to register to receive Vibecode Starter Kit v0.1 to start building AI products according to this process. Link in bio!

---

**Visual Notes**:  
- Start with a surprised expression, then turn confident when explaining  
- Text appears with each role: Homeowner, AI Assistant, Builder  
- Simple animation effects, computer icons, AI robots, illustration builders  
- At the end of the video, the Vibecode logo and a call for registration are displayed  

**Audio Notes**:  
- Bright background music, moderately fast beat  
- Friendly, inspiring, slightly excited voice  

**Caption for Post**:  
Don't know how to code? No problem! With these 3 roles, you can also build AI! Get the Vibecode Starter Kit now! #AIkhongcode #Vibecode #NoCodeAI

---