# Intake example for Web App
(Sample content...)