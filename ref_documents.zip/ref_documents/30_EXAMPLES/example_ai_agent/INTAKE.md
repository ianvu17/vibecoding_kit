# Intake example for AI Agent
(Sample content...)