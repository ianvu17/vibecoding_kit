# Metrics & Retro Checklist – Vibecode Launch

*Monitor data and summarize after 30 days of launch.*

---

## 1. Metrics to track

### 1.1. Awareness Metrics

| Metrics | How to measure | Goal | Reality |
|--------|---------|----------|---------|
| Total reach (posts) | FB Insights | [OWNER_TODO] | _____ |
| Total views (stories) | FB Insights | [OWNER_TODO] | _____ |
| Number of livestream viewers | FB Live stats | [OWNER_TODO] | _____ |
| Profile visits | FB Insights | [OWNER_TODO] | _____ |

### 1.2. Engagement Metrics

| Metrics | How to measure | Goal | Reality |
|--------|---------|----------|---------|
| Total reactions | Count manual / Insights | [OWNER_TODO] | _____ |
| Total comments | Count manual / Insights | [OWNER_TODO] | _____ |
| Total shares | Count manual / Insights | [OWNER_TODO] | _____ |
| Inbox number asking about Vibecode | Counting manual | [OWNER_TODO] | _____ |

### 1.3. Interest Metrics

| Metrics | How to measure | Goal | Reality |
|--------|---------|----------|---------|
| Number of people registering interest form | Google Form / Typeform | [OWNER_TODO] | _____ |
| Number of clicks on links | Bitly / UTM tracking | [OWNER_TODO] | _____ |
| Number of people saving post | FB Insights | [OWNER_TODO] | _____ |

### 1.4. Conversion Metrics

| Metrics | How to measure | Goal | Reality |
|--------|---------|----------|---------|
| Number of buyers | Counting manual | [OWNER_TODO] | _____ |
| Revenue | Total Payment | [OWNER_TODO] | _____ |
| Conversion rate | Buy / Interested | [OWNER_TODO] | _____ |
| Average order value | Revenue / Number of orders | [OWNER_TODO] | _____ |

---

## 2. Weekly checklist

### Week 1 (Day 1-7): WARM-UP

**Job:**
- [ ] Post 5-6 articles according to calendar
- [ ] Reply all comments
- [ ] Reply to inbox during the day
- [ ] Open the interest registration form

**Data to record:**
| Date | Post | Reach | Reactions | Comments | Inbox |
|-------|-------|-------|-----------|----------|-------|
| Day 1 | | | | | |
| Day 2 | | | | | |
| Day 3 | | | | | |
| Day 4 | | | | | |
| Day 5 | | | | | |
| Day 6 | | | | | |
| Day 7 | | | | | |

**Weekend review:**
- Total reach: _____
- Number of interested people: _____
- Which song has the highest engagement: _____
- Adjustment for week 2: _____

---

### Week 2 (Day 8-14): DEMO (Part 1)

**Job:**
- [ ] Post 6-7 articles according to calendar
- [ ] Livestream #1 (Day 12)
- [ ] Post recap after livestream
- [ ] Start collecting testimonials

**Data to record:**
| Date | Post | Reach | Reactions | Comments | Inbox |
|-------|-------|-------|-----------|----------|-------|
| Day 8 | | | | | |
| Day 9 | | | | | |
| Day 10 | | | | | |
| Day 11 | | | | | |
| Day 12 | Livestream | | | | |
| Day 13 | | | | | |
| Day 14 | | | | | |

**Livestream #1 stats:**
- Peak viewers: _____
- Total views: _____
- Comments: _____
- Shares: _____

**Weekend review:**
- Total reach: _____
- Number of new interested people: _____
- Feedback from livestream: _____

---

### Week 3 (Day 15-21): DEMO (Part 2) + CONVERT

**Job:**
- [ ] Open pre-order (Day 16)
- [ ] Post 5-6 articles according to calendar
- [ ] Livestream #2 Q&A (Day 20)
- [ ] Follow up inbox for interest

**Data to record:**
| Date | Post | Reach | Reactions | Comments | Subscribe/Buy |
|-------|--------|-------|-----------|----------|-------------|
| Day 15 | | | | | |
| Day 16 | Open pre-order | | | | |
| Day 17 | | | | | |
| Day 18 | | | | | |
| Day 19 | | | | | |
| Day 20 | Livestream | | | | |
| Day 21 | | | | | |

**Livestream #2 stats:**
- Peak viewers: _____
- Total views: _____
- Question asked: _____

**Weekend review:**
- Number of people who bought: _____
- Accumulated revenue: _____
- Top objections: _____

---

### Week 4 (Day 22-30): CLOSING

**Job:**
- [ ] Post 7-9 articles (increase final frequency)
- [ ] Remind the deadline many times
- [ ] Follow up people who haven't decided yet
- [ ] Close batch, thank you

**Data to record:**
| Date | Post | Reach | Reactions | Comments | Subscribe/Buy |
|-------|--------|-------|-----------|----------|-------------|
| Day 22 | | | | | |
| Day 23 | | | | | |
| Day 24 | | | | | |
| Day 25 | | | | | |
| Day 26 | | | | | |
| Day 27 | | | | | |
| Day 28 | | | | | |
| Day 29 | | | | | |
| Day 30 | Close batch | | | | |**Final result:**
- Total number of buyers: _____
- Total revenue: _____
- Conversion rate: _____

---

## 3. Retrospective after 30 days

### 3.1. Results vs Goals

| Index | Goal | Reality | % Pass |
|--------|----------|--------|-------|
| Number of buyers | [OWNER_TODO] | _____ | ___% |
| Revenue | [OWNER_TODO] | _____ | ___% |
| Number of interested people | [OWNER_TODO] | _____ | ___% |
| Livestream number | [OWNER_TODO] | _____ | ___% |

### 3.2. Retro Question

**What works best?**
```
[OWNER_TODO] Record:
- Which channel brings the most conversions?
- Which type of content has the highest engagement?
- Which message resonates?
```

**What doesn't work?**
```
[OWNER_TODO] Record:
- Which content flops?
- Which channel is not worth effort?
- Which Objects have not been resolved?
```

**If you were to do it all over again, what would you do differently?**
```
[OWNER_TODO] Record:
- Changes to the timeline?
- Messaging changes?
- Channel changes?
```

**Biggest lesson?**
```
[OWNER_TODO] Record 1-3 key lessons.
```

### 3.3. Idea for Batch 2

**Product improvement:**
```
[OWNER_TODO] Feedback from batch 1 needs address:
-
-
```

**Improved marketing:**
```
[OWNER_TODO] Changes for launch batch 2:
-
-
```

**Improved operations:**
```
[OWNER_TODO] Process needs optimization:
-
-
```

---

## 4. Definition of "Success"

[OWNER_TODO] Fill in before starting launch:

**Batch 1 is considered successful if:**

| Tier | Conditions | Status |
|-------|-----------|--------|
| Minimum | _____ buyers, _____ VND revenue | [ ] |
| Target | _____ buyers, _____ VND revenue | [ ] |
| Stretch | _____ buyers, _____ VND revenue | [ ] |

**In addition to sales, success is also:**
- [ ] Validate product-market fit
- [ ] Have ≥3 good testimonials
- [ ] Learn how to launch
- [ ] Have data to improve batch 2

---

## 5. Suggested tools

**Tracking:**
- Facebook Insights (reach, engagement)
- Google Forms (registration form)
- Bitly (track link clicks)
- Google Sheets (record data)

**Automation:**
- Buffer/Later (schedule posts)
- Notion (content calendar)

**Communication:**
- Messenger (1:1 follow up)
- Email (nurture sequence)

[OWNER_TODO] Choose tools that suit your workflow.

---

*This document is part 5/5 of the Launch Plan. Good luck with your launch!*