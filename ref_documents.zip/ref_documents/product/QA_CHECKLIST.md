# QA Checklist – Vibecode Starter Kit v0.1

*Checklist to clean basecode before tagging v0.1.0 and launch.*

---

## 1. Repo structure

### 1.1. Organize JOBs for new users

**Problem:** There are currently 7 JOBs (JOB-001 → JOB-103) which are the build history of the kit. New users may be overwhelmed or confused.

**Suggested solution:**

- [ ] Move JOB-001 → JOB-103 to `_history/` or `owner/build-history/`
- [ ] Retain `examples/` with 2 existing sample JOBs (enough for user reference)
- [ ] Make sure `jobs/`, `blueprints/`, `contracts/`, `logs/` are empty for the user

**Or:**

- [ ] Added note in README: "JOB-001 to JOB-103 are the build history of this kit, you can delete or keep as reference"

---

### 1.2. Add file VERSION/CHANGELOG

- [ ] Add version in README.md: `v0.1.0`
- [ ] Create file `CHANGELOG.md`:
  ```md
  #Changelog

  ## v0.1.0 (2024-XX-XX)
  - Initial release
  - Docs: Overview, Playbook, Quickstart 7 days
  - Templates: JOB, Blueprint, Contracts, Log
  - Scripts: vibe.py CLI tool
  - Examples: 2 sample JOBs
  - Prompts: Master prompts for ChatGPT & Claude
  - Product: Brief, Packages, Sales Page draft
  - Launch: 30-day launch plan
  ```

---

## 2. Format [OWNER_TODO]

### 2.1. Detection problem

There are **2 different formats** being used:

1. **Inline format:** `[OWNER_TODO]` or `[OWNER_TODO: mô tả...]` (89 instances)
2. **HTML comment:** `<!-- OWNER_TODO: mô tả... -->` (29 instances)

**Files have HTML comment format:**
- `docs/01_overview.md` (7 instances)
- `docs/02_vibecode_playbook.md` (13 instances)
- `docs/03_quickstart_7_days.md` (10 instances)
- `product/PACKAGES.md` (2 instances)
- `product/PRODUCT_BRIEF.md` (2 instances)

### 2.2. Decisions need to be made

- [ ] **Option A:** Normalize all to inline format `[OWNER_TODO: ...]`
  - Pros: Visible when reading, easy to search
  - Disadvantage: Displayed in rendered markdown

- [ ] **Option B:** Keep HTML comments for long instructions, inline for short instructions
  - Pros: Cleaner when rendering
  - Disadvantage: Inconsistent

**Recommend:** Option A - unified inline format because:
- Easy to grep the entire repo: `grep -r "\[OWNER_TODO" .`
- Users immediately see what needs to be filled in

### 2.3. Command to search all TODO

```bash
grep -rn "OWNER_TODO" --include="*.md" .
```

---

## 3. Scripts/vibe.py

### 3.1. Good point

- [x] Use `Path(__file__).resolve().parent` → run from anywhere
- [x] There is error handling for files that do not exist
- [x] Can skip when the file already exists (no overwrite)
- [x] Help text is clear with examples

### 3.2. Points for improvement

- [ ] Template path in `cmd_new()` hardcode: `templates/jobs/JOB-intake-template.md`
  - But the real file is: `templates/jobs/JOB-intake-example.md`
  - **Need to check if the template files have the correct name**

- [ ] Verify template files exist:
  ```bash
  ls templates/jobs/
  ls templates/blueprints/
  ls templates/contracts/
  ls templates/logs/
  ```

### 3.3. Test command

- [ ] Test `python scripts/vibe.py --help`
- [ ] Test `python scripts/vibe.py new TEST-001`
- [ ] Test `python scripts/vibe.py pack-architect TEST-001`
- [ ] Test `python scripts/vibe.py pack-coder TEST-001 STEP-1`
- [ ] Test `python scripts/vibe.py log TEST-001 "Test note"`
- [ ] Cleanup: delete TEST-001 files after testing

---

## 4. Prompts

### 4.1. Consistency check

- [x] Architect prompt prompts for correct folder structure: `jobs/`, `blueprints/`, `contracts/`, `logs/`
- [x] Coder prompt prompts for correct format STEP + GATE
- [x] Both prompts use consistent terms: "Owner", "Architect", "Coder"

### 4.2. Points to verify

- [ ] Architect prompt line 158-161 lists paths → verify is still correct
- [ ] Coder prompt prompts `contracts/<job_id>-contracts.md` → correct pattern

---

## 5. Docs Consistency

### 5.1. Cross-reference checking

- [ ] `01_overview.md` → only introduction, not in-depth process
- [ ] `02_playbook.md` → detailed process, no repeat overview
- [ ] `03_quickstart.md` → step-by-step 7 days, no repeat philosophy

### 5.2. Naming consistency

Verify unified product name:
- [ ] Search "Vibecode Starter Kit" → correct official name
- [ ] Search "Vibecode kit" (lowercase) → consider changing to the official name
- [ ] Search "Vibecode Playbook" → only used for file names, not product names

---

## 6. Product & Pricing

### 6.1. Placeholder check

- [ ] Search `XXX.000` to find unfilled prices
- [ ] Search `X slot` to find the number of unfilled slots
- [ ] Make sure there are no old "hard" prices missing

### 6.2. Bio & Contact consistency

- [ ] Bio in Sales Page ↔ Bio in Launch docs → consistent
- [ ] Contact info placeholder in all necessary places

---

## 7. Launch Plan

### 7.1. Actual channel

- [ ] `LAUNCH_30D_OVERVIEW.md` → fill in actual channel
- [ ] `CONTENT_CALENDAR_30D.md` → fill in actual Day 1### 7.2. Target Metrics

- [ ] Fill in the target number of buyers
- [ ] Fill in revenue target
- [ ] Fill in the definition of "success"

---

## 8. Pre-Launch Checklist

### Technical

- [ ] Clean repo: move/delete JOB history
- [ ] Standardize OWNER_TODO format
- [ ] Test vibe.py working properly
- [ ] Tag `v0.1.0` in git

### Content

- [ ] Fill in all [OWNER_TODO] in Sales Page
- [ ] Fill in bio, price, payment link
- [ ] Enter Day 1 in the calendar

### Infrastructure

- [ ] Payment link works
- [ ] Interest registration form is ready
- [ ] Repo/zip ready to send

---

## Done

**Priority 1 (Critical):**
1. Verify template files for vibe.py
2. Standardize the OWNER_TODO format
3. Fill in Sales Page essentials (price, bio, CTA)

**Priority 2 (Important):**
1. Clean JOB history
2. Test vibe.py commands
3. Fill in Launch metrics

**Priority 3 (Nice to have):**
1. Add CHANGELOG.md
2. Cross-check docs consistency
3. Add tests to vibe.py

---

*This checklist should be gradually ticked before Day 1 launch.*