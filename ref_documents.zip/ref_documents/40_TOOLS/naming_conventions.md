# Naming Conventions

## Project directory
- Always have folder `.vibecode/` at the root to store design documents.

## Job ID (Job ID)
- `JOB-001-Setup`: Environment settings.
- `JOB-002-Database`: DB design.
- `JOB-010-UI-Login`: Make Login interface.

## Versioning
- Blueprint v1.0, v1.1...
- Always backup old files before major updates.